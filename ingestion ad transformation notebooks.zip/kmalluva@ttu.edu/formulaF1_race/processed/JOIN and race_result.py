# Databricks notebook source
spark.conf.set("fs.azure.account.key.formula1dlprj25.dfs.core.windows.net","f7uc/rpPf7iG+ZDMf5pw6T4JVUgZai/CrnD1W9idUM3xnjJex0h05EWgFPDDOzEySwM+L6JRTRs7+AStyid4xg==")

# COMMAND ----------

circuit_df = spark.read.parquet("abfss://processed@formula1dlprj25.dfs.core.windows.net/circuit.csv")

# COMMAND ----------

display(circuit_df)


# COMMAND ----------

processed_folder_path ='abfss://processed@formula1dlprj25.dfs.core.windows.net'
constr_df=spark.read.parquet(f"{processed_folder_path}/constructors.json") \
.withColumnRenamed("name", "team")

# COMMAND ----------

display(constr_df)

# COMMAND ----------

processed_folder_path ='abfss://processed@formula1dlprj25.dfs.core.windows.net'
races_df=spark.read.parquet(f"{processed_folder_path}/races.csv")

# COMMAND ----------

display(races_df)

# COMMAND ----------

processed_folder_path ='abfss://processed@formula1dlprj25.dfs.core.windows.net'
driver_df=spark.read.parquet(f"{processed_folder_path}/drivers.json") \
.withColumnRenamed("number", "driver_number") \
.withColumnRenamed("name", "driver_name") \
.withColumnRenamed("nationality", "driver_nationality") 

# COMMAND ----------

display(driver_df)

# COMMAND ----------

processed_folder_path ='abfss://processed@formula1dlprj25.dfs.core.windows.net'
results_df=spark.read.parquet(f"{processed_folder_path}/results.json") \
    .withColumnRenamed("time", "race_time") 

# COMMAND ----------

display(results_df)

# COMMAND ----------

processed_folder_path ='abfss://processed@formula1dlprj25.dfs.core.windows.net'
driver_df=spark.read.parquet(f"{processed_folder_path}/drivers.json") \
.withColumnRenamed("number", "driver_number") \
.withColumnRenamed("name", "driver_name") \
.withColumnRenamed("nationality", "driver_nationality") 

# COMMAND ----------

display(driver_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Join Circuit and Race

# COMMAND ----------

race_circuit_df = races_df.join(circuit_df, races_df.circuit_id==circuit_df.circuit_id, "inner") \
    .select(races_df.race_id, races_df.racer_year, races_df.name, circuit_df.location)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Join results to all other dataframes

# COMMAND ----------

race_result_df = results_df.join(race_circuit_df, results_df.race_id==race_circuit_df.race_id,"inner") \
                           .join(constr_df,results_df.constructor_id==constr_df.constructor_Id) \
                           .join(driver_df,results_df.driver_id==driver_df.driver_Id)
                          

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

final_df = race_result_df.select("racer_year", "name", "location", "driver_name", "driver_number", "driver_nationality", "team", "grid", "fastest_lap", "race_time", "points", "position") \
                .withColumn("created_date", current_timestamp())

# COMMAND ----------

presentation_folder_path='abfss://presentation@formula1dlprj25.dfs.core.windows.net'
final_df.write.mode("overwrite").parquet(f"{presentation_folder_path}/race_results")

# COMMAND ----------

display(race_result_df)

# COMMAND ----------

final_df.write.format("parquet").saveAsTable("f1_presentation.race_tables")

# COMMAND ----------

