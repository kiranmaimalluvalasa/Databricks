-- Databricks notebook source
-- MAGIC %python
-- MAGIC spark.conf.set("fs.azure.account.key.formula1dlprj25.dfs.core.windows.net","f7uc/rpPf7iG+ZDMf5pw6T4JVUgZai/CrnD1W9idUM3xnjJex0h05EWgFPDDOzEySwM+L6JRTRs7+AStyid4xg==")

-- COMMAND ----------

DESC DATABASE f1_processed

-- COMMAND ----------

use f1_processed

-- COMMAND ----------


SELECT * FROM f1_processed.results
JOIN f1_processed.drivers ON (results.driver_id = drivers.driver_id)
JOIN f1_processed.constructors ON (results.constructor_id = constructors.constructor_Id)
JOIN f1_processed.races ON (results.race_id = races.race_id)

-- COMMAND ----------

DROP TABLE IF EXISTS f1_presentation.calculated_race_results;
CREATE TABLE f1_presentation.calculated_race_results
USING parquet 
AS
SELECT races.racer_year, 
       constructors.name as team_name, 
       results.position,
       results.points, 
       drivers.name as driver_name, 
       11 - results.position AS calculated_points 
FROM f1_processed.results
JOIN f1_processed.drivers ON (results.driver_id = drivers.driver_id)
JOIN f1_processed.constructors ON (results.constructor_id = constructors.constructor_Id)
JOIN f1_processed.races ON (results.race_id = races.race_id)
WHERE results.position <= 10;

-- COMMAND ----------

select * from f1_presentation.calculated_race_results
where racer_year=1996;