-- Databricks notebook source
-- MAGIC
-- MAGIC
-- MAGIC %python
-- MAGIC spark.conf.set("fs.azure.account.key.formula1dlprj25.dfs.core.windows.net","f7uc/rpPf7iG+ZDMf5pw6T4JVUgZai/CrnD1W9idUM3xnjJex0h05EWgFPDDOzEySwM+L6JRTRs7+AStyid4xg==")

-- COMMAND ----------

REFRESH TABLE f1_presentation.calculated_race_results;

-- COMMAND ----------

SELECT * FROM f1_presentation.calculated_race_results;

-- COMMAND ----------

SELECT team_name,COUNT(1) AS total_race,SUM(calculated_points) AS total_points,AVG(calculated_points) AS avg_points
FROM f1_presentation.calculated_race_results
where racer_year BETWEEN 2001 AND 2010
GROUP BY team_name
HAVING COUNT(1) >= 50
ORDER BY avg_points DESC