-- Databricks notebook source
-- MAGIC
-- MAGIC
-- MAGIC %python
-- MAGIC spark.conf.set("fs.azure.account.key.formula1dlprj25.dfs.core.windows.net","f7uc/rpPf7iG+ZDMf5pw6T4JVUgZai/CrnD1W9idUM3xnjJex0h05EWgFPDDOzEySwM+L6JRTRs7+AStyid4xg==")

-- COMMAND ----------

REFRESH TABLE f1_presentation.calculated_race_results;

-- COMMAND ----------

SELECT * FROM f1_presentation.calculated_race_results;

-- COMMAND ----------

CREATE OR REPLACE TEMP VIEW v_dominant_driver 
AS
SELECT driver_name,
       COUNT(1) AS total_race, 
       SUM(calculated_points) AS total_points, 
       AVG(calculated_points) AS avg_points,
       RANK() OVER (ORDER BY AVG(calculated_points) DESC) as driver_rank
FROM f1_presentation.calculated_race_results
GROUP BY driver_name
HAVING COUNT(1) >= 50
ORDER BY avg_points DESC

-- COMMAND ----------

SELECT racer_year,driver_name,COUNT(1) AS total_race,SUM(calculated_points) AS total_points,AVG(calculated_points) AS avg_points
FROM f1_presentation.calculated_race_results
GROUP BY driver_name,racer_year
ORDER BY racer_year,avg_points DESC

-- COMMAND ----------

SELECT racer_year, 
       driver_name, 
       COUNT(1) AS total_race, 
       SUM(calculated_points) AS total_points, 
       AVG(calculated_points) AS avg_points
FROM f1_presentation.calculated_race_results
WHERE driver_name IN (SELECT driver_name FROM v_dominant_driver WHERE driver_rank <= 10)
GROUP BY racer_year, driver_name
ORDER BY racer_year, avg_points DESC