# Databricks notebook source
# MAGIC %md
# MAGIC ###intoduction to access key( using secret scope and key values)
# MAGIC 1.setup the spark conf 
# MAGIC 2. list the files for demo container
# MAGIC #### secret scope and key values helps us to secure the access keys  

# COMMAND ----------

formula1dl_account_key = dbutils.secrets.get(scope = 'formula1-scope', key = 'formulaf1-account-keyvalue')

# COMMAND ----------

spark.conf.set("fs.azure.account.key.formula1dlprj25.dfs.core.windows.net",formula1dl_account_key)


# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@formula1dlprj25.dfs.core.windows.net"))

# COMMAND ----------

display(spark.read.csv("abfss://demo@formula1dlprj25.dfs.core.windows.net/circuits.csv"))