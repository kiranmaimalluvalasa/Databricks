# Databricks notebook source
# MAGIC %md
# MAGIC ###intoduction to access key
# MAGIC 1.setup the spark conf 
# MAGIC 2. list the files for demo container

# COMMAND ----------

spark.conf.set("fs.azure.account.key.formula1dlprj25.dfs.core.windows.net","f7uc/rpPf7iG+ZDMf5pw6T4JVUgZai/CrnD1W9idUM3xnjJex0h05EWgFPDDOzEySwM+L6JRTRs7+AStyid4xg==")


# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@formula1dlprj25.dfs.core.windows.net"))

# COMMAND ----------

display(spark.read.csv("abfss://demo@formula1dlprj25.dfs.core.windows.net/circuits.csv"))