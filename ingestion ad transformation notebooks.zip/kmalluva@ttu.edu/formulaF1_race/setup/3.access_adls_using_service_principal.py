# Databricks notebook source
# MAGIC %md
# MAGIC ### Access Azure Data Lake using Service Principal
# MAGIC #### Steps to follow
# MAGIC 1. Register Azure AD Application / Service Principal
# MAGIC 1. Generate a secret/ password for the Application
# MAGIC 1. Set Spark Config with App/ Client Id, Directory/ Tenant Id & Secret
# MAGIC 1. Assign Role 'Storage Blob Data Contributor' to the Data Lake. 
# MAGIC

# COMMAND ----------

client_id ="e27f7bbb-ba5a-4d4e-8257-bd30e0bd84ec"
tenant_id = "178a51bf-8b20-49ff-b655-56245d5c173c"
client_secret ="3w68Q~YG27a3w9L6avDKoGmoAsjpz3YYxEtCHcgY"

# COMMAND ----------

spark.conf.set("fs.azure.account.auth.type.formula1dlprj25.dfs.core.windows.net", "OAuth")
spark.conf.set("fs.azure.account.oauth.provider.type.formula1dlprj25.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set("fs.azure.account.oauth2.client.id.formula1dlprj25.dfs.core.windows.net", client_id)
spark.conf.set("fs.azure.account.oauth2.client.secret.formula1dlprj25.dfs.core.windows.net", client_secret)
spark.conf.set("fs.azure.account.oauth2.client.endpoint.formula1dlprj25.dfs.core.windows.net", f"https://login.microsoftonline.com/{tenant_id}/oauth2/token")

# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@formula1dlprj25.dfs.core.windows.net"))

# COMMAND ----------

display(spark.read.csv("abfss://demo@formula1dlprj25.dfs.core.windows.net/circuits.csv"))