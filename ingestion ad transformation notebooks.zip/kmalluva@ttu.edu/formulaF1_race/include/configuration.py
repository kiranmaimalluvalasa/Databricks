# Databricks notebook source
#raw_folder_path ='abfss://raw1@formula1dlprj25.dfs.core.windows.net'
#processed_folder_path ='abfss://processed@formula1dlprj25.dfs.core.windows.net'
#presentation_folder_path='abfss://presentation@formula1dlprj25.dfs.core.windows.net'

# COMMAND ----------

