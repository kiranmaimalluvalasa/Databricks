-- Databricks notebook source
-- MAGIC %python
-- MAGIC spark.conf.set("fs.azure.account.key.formula1dlprj25.dfs.core.windows.net","f7uc/rpPf7iG+ZDMf5pw6T4JVUgZai/CrnD1W9idUM3xnjJex0h05EWgFPDDOzEySwM+L6JRTRs7+AStyid4xg==")

-- COMMAND ----------

CREATE DATABASE IF NOT EXISTS f1_processed
LOCATION 'abfss://formula1dlprj25.dfs.core.windows.net/processed'

-- COMMAND ----------

SHOW DATABASES


-- COMMAND ----------

DESC DATABASE f1_processed

-- COMMAND ----------

SELECT * FROM f1_processed.circuit

-- COMMAND ----------

SELECT * FROM f1_processed.races

-- COMMAND ----------

SELECT * FROM f1_processed.constructors;

-- COMMAND ----------

select * from f1_processed.drivers;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC spark.conf.set("fs.azure.account.key.formula1dlprj25.dfs.core.windows.net","f7uc/rpPf7iG+ZDMf5pw6T4JVUgZai/CrnD1W9idUM3xnjJex0h05EWgFPDDOzEySwM+L6JRTRs7+AStyid4xg==")

-- COMMAND ----------

CREATE DATABASE IF NOT EXISTS f1_presentation


