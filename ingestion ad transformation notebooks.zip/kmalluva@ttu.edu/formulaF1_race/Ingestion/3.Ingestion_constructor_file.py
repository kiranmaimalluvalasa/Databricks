# Databricks notebook source
spark.conf.set("fs.azure.account.key.formula1dlprj25.dfs.core.windows.net","f7uc/rpPf7iG+ZDMf5pw6T4JVUgZai/CrnD1W9idUM3xnjJex0h05EWgFPDDOzEySwM+L6JRTRs7+AStyid4xg==")

# COMMAND ----------

# MAGIC %run "../include/configuration"

# COMMAND ----------

#raw_folder_path ='abfss://raw1@formula1dlprj25.dfs.core.windows.net'
#processed_folder_path ='abfss://processed@formula1dlprj25.dfs.core.windows.net'
#presentation_folder_path='abfss://presentation@formula1dlprj25.dfs.core.windows.net'

# COMMAND ----------

display(dbutils.fs.ls("abfss://raw1@formula1dlprj25.dfs.core.windows.net"))

# COMMAND ----------

 const_df = (spark.read.json("abfss://raw1@formula1dlprj25.dfs.core.windows.net/constructors.json"))

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType

# COMMAND ----------

constructor_schema = StructType(fields=[StructField("constructorId", IntegerType(), False),
                                        StructField("constructorRef", StringType(), True),
                                        StructField("name", StringType(), True),
                                        StructField("nationality", StringType(), True),
                                        StructField("url", StringType(), True) 
])

# COMMAND ----------

const_df = (spark.read.schema(constructor_schema).json("abfss://raw1@formula1dlprj25.dfs.core.windows.net/constructors.json"))

# COMMAND ----------

from pyspark.sql.functions import col

# COMMAND ----------

const_df_drop = const_df.drop(col('url'))

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

const_df_timestamp = const_df_drop.withColumnRenamed("constructorId","constructor_Id") \
                                  .withColumnRenamed("constructorRef","constructor_Ref") \
                                  .withColumn("ingestion_date",current_timestamp()) 
                    
    

# COMMAND ----------

processed_folder_path ='abfss://processed@formula1dlprj25.dfs.core.windows.net'
const_df_timestamp.write.mode('overwrite').parquet(f"{processed_folder_path}/constructors.json")

# COMMAND ----------

const_df_timestamp.write.mode('overwrite').format("parquet").saveAsTable("f1_processed.constructors")