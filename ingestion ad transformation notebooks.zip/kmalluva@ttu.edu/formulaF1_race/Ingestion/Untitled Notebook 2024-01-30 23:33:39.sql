-- Databricks notebook source
show databases;

-- COMMAND ----------

USE f1_presentation

-- COMMAND ----------

SHOW TABLES IN f1_presentation;

-- COMMAND ----------

DESC driver_table;

-- COMMAND ----------

CREATE OR REPLACE TEMP VIEW v_driver_2018
AS
SELECT racer_year,driver_name,Total_points,team,wins,rank
FROM driver_table
WHERE racer_year=2018;

-- COMMAND ----------

CREATE OR REPLACE TEMP VIEW v_driver_2020
AS
SELECT racer_year,driver_name,Total_points,team,wins,rank
FROM driver_table
WHERE racer_year=2020;

-- COMMAND ----------

SELECT * 
  FROM v_driver_2018 d_2018
  JOIN v_driver_2020 d_2020
   ON(d_2018.driver_name = d_2020.driver_name)


-- COMMAND ----------

SELECT * 
  FROM v_driver_2018 d_2018
  CROSS JOIN v_driver_2020 d_2020
   ON(d_2018.driver_name = d_2020.driver_name)

-- COMMAND ----------

