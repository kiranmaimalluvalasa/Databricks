# Databricks notebook source
spark.conf.set("fs.azure.account.key.formula1dlprj25.dfs.core.windows.net","f7uc/rpPf7iG+ZDMf5pw6T4JVUgZai/CrnD1W9idUM3xnjJex0h05EWgFPDDOzEySwM+L6JRTRs7+AStyid4xg==")

# COMMAND ----------

display(dbutils.fs.ls("abfss://raw1@formula1dlprj25.dfs.core.windows.net"))

# COMMAND ----------

qualify_times_df = (spark.read.json("abfss://raw1@formula1dlprj25.dfs.core.windows.net/qualifying/"))

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType

# COMMAND ----------

qualifying_schema = StructType(fields=[StructField("qualifyId", IntegerType(), False),
                                      StructField("raceId", IntegerType(), True),
                                      StructField("driverId", IntegerType(), True),
                                      StructField("constructorId", IntegerType(), True),
                                      StructField("number", IntegerType(), True),
                                      StructField("position", IntegerType(), True),
                                      StructField("q1", StringType(), True),
                                      StructField("q2", StringType(), True),
                                      StructField("q3", StringType(), True),
                                     ])

# COMMAND ----------

 qual_times_df = (spark.read.schema(qualifying_schema).option("multiLine",True).json("abfss://raw1@formula1dlprj25.dfs.core.windows.net/qualifying/"))

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

final_df = qual_times_df.withColumnRenamed("qualifyId", "qualify_id") \
.withColumnRenamed("driverId", "driver_id") \
.withColumnRenamed("raceId", "race_id") \
.withColumnRenamed("constructorId", "constructor_id") \
.withColumn("ingestion_date", current_timestamp())
                    
    

# COMMAND ----------

final_df.write.mode('overwrite').parquet('abfss://processed@formula1dlprj25.dfs.core.windows.net/qualifying/')

# COMMAND ----------

final_df.write.mode('overwrite').format("parquet").saveAsTable("f1_processed.qualifying")