# Databricks notebook source
dbutils.notebook.help()

# COMMAND ----------

dbutils.notebook.run("(Clone) 1.ingestion_circuit_file",0,{"data_source":"tested"})