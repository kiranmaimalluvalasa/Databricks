# Databricks notebook source
# MAGIC %md
# MAGIC ### Ingest race.csv file

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Step 1 - Read the CSV file using the spark dataframe reader

# COMMAND ----------

spark.conf.set("fs.azure.account.key.formula1dlprj25.dfs.core.windows.net","f7uc/rpPf7iG+ZDMf5pw6T4JVUgZai/CrnD1W9idUM3xnjJex0h05EWgFPDDOzEySwM+L6JRTRs7+AStyid4xg==")

# COMMAND ----------

display(dbutils.fs.ls("abfss://raw1@formula1dlprj25.dfs.core.windows.net"))

# COMMAND ----------

display(spark.read.csv("abfss://raw1@formula1dlprj25.dfs.core.windows.net/races.csv"))

# COMMAND ----------

racers_df=(spark.read.option('header',True).csv("abfss://raw1@formula1dlprj25.dfs.core.windows.net/races.csv"))

# COMMAND ----------

display(racers_df)

# COMMAND ----------

racers_df.show()

# COMMAND ----------

racers_df.printSchema()

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType

# COMMAND ----------

races_schema = StructType(fields=[StructField("raceId", IntegerType(), False),
                                  StructField("year", IntegerType(), True),
                                  StructField("round", IntegerType(), True),
                                  StructField("circuitId", IntegerType(), True),
                                  StructField("name", StringType(), True),
                                  StructField("date", DateType(), True),
                                  StructField("time", StringType(), True),
                                  StructField("url", StringType(), True) 
])                 

# COMMAND ----------

racers_df=(spark.read.option('header',True) \
           .schema(races_schema) \
           .csv("abfss://raw1@formula1dlprj25.dfs.core.windows.net/races.csv"))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Step 2 - Add ingestion date and race_timestamp to the dataframe

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, to_timestamp,concat,lit,col

# COMMAND ----------

racers_df_timestamp = racers_df.withColumn("ingestion_date",current_timestamp()) \
                               .withColumn("race_timestamp", to_timestamp(concat(col('date'), lit(' '), col('time')), 'yyyy-MM-dd HH:mm:ss'))

 

# COMMAND ----------

# MAGIC %md
# MAGIC ####3.rename

# COMMAND ----------

racers_selected_df=racers_df_timestamp.select(col("raceId").alias("race_id"),col("year").alias("racer_year"),col("name"),col("round"),col("circuitId").alias("circuit_id"),col("name").alias("racer_name"),col("url"))

# COMMAND ----------

# MAGIC %md
# MAGIC ####2.partition by year

# COMMAND ----------

processed_folder_path ='abfss://processed@formula1dlprj25.dfs.core.windows.net'
racers_selected_df.write.mode('overwrite').partitionBy('racer_year').parquet(f"{processed_folder_path}/races.csv")

# COMMAND ----------

racers_selected_df.write.mode('overwrite').format("parquet").saveAsTable("f1_processed.races")