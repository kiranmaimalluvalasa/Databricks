# Databricks notebook source
spark.conf.set("fs.azure.account.key.formula1dlprj25.dfs.core.windows.net","f7uc/rpPf7iG+ZDMf5pw6T4JVUgZai/CrnD1W9idUM3xnjJex0h05EWgFPDDOzEySwM+L6JRTRs7+AStyid4xg==")

# COMMAND ----------

display(dbutils.fs.ls("abfss://raw1@formula1dlprj25.dfs.core.windows.net"))

# COMMAND ----------

lap_times_df = (spark.read.json("abfss://raw1@formula1dlprj25.dfs.core.windows.net/lap_times/"))

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType

# COMMAND ----------

lap_times_schema = StructType(fields=[StructField("raceId", IntegerType(), False),
                                      StructField("driverId", IntegerType(), True),
                                      StructField("lap", IntegerType(), True),
                                      StructField("position", IntegerType(), True),
                                      StructField("time", StringType(), True),
                                      StructField("milliseconds", IntegerType(), True)
                                     ])

# COMMAND ----------

 lap_times_df = (spark.read.schema(lap_times_schema).csv("abfss://raw1@formula1dlprj25.dfs.core.windows.net/lap_times/"))

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

final_df = lap_times_df.withColumnRenamed("driverId", "driver_id") \
.withColumnRenamed("raceId", "race_id") \
.withColumn("ingestion_date", current_timestamp())
                    
    

# COMMAND ----------

final_df.write.mode('overwrite').parquet('abfss://processed@formula1dlprj25.dfs.core.windows.net/lap_times/')

# COMMAND ----------

final_df.write.mode('overwrite').format("parquet").saveAsTable("f1_processed.lap")