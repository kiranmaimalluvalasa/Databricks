# Databricks notebook source
spark.conf.set("fs.azure.account.key.formula1dlprj25.dfs.core.windows.net","f7uc/rpPf7iG+ZDMf5pw6T4JVUgZai/CrnD1W9idUM3xnjJex0h05EWgFPDDOzEySwM+L6JRTRs7+AStyid4xg==")

# COMMAND ----------

display(dbutils.fs.ls("abfss://raw1@formula1dlprj25.dfs.core.windows.net"))

# COMMAND ----------

 driver_df = (spark.read.json("abfss://raw1@formula1dlprj25.dfs.core.windows.net/drivers.json"))

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType

# COMMAND ----------

name_schema= StructType(fields=[StructField("forename",StringType(), True),
                                 StructField("surname",StringType(), True) ])

# COMMAND ----------

driver_schema = StructType(fields=[StructField("driverId", IntegerType(), False),
                                        StructField("driverRef", StringType(), True),
                                        StructField("name",name_schema ),
                                        StructField("nationality", StringType(), True),
                                        StructField("code", StringType(), True),
                                        StructField("dob", DateType(), True),
                                        StructField("number", IntegerType(), True),
                                        StructField("url", StringType(), True) 
])

# COMMAND ----------

driver_df = (spark.read.schema(driver_schema).json("abfss://raw1@formula1dlprj25.dfs.core.windows.net/drivers.json"))

# COMMAND ----------

from pyspark.sql.functions import col

# COMMAND ----------

driver_df_drop = driver_df.drop(col('url'))

# COMMAND ----------

from pyspark.sql.functions import current_timestamp,col,lit,concat

# COMMAND ----------

driver_df_timestamp = driver_df_drop.withColumnRenamed("driverId","driver_Id") \
                                  .withColumnRenamed("driverRef","driver_Ref") \
                                  .withColumn("ingestion_date",current_timestamp()) \
                                  .withColumn("name",concat(col("name.forename"),lit(""),col("name.surname")))
                    
    

# COMMAND ----------

processed_folder_path ='abfss://processed@formula1dlprj25.dfs.core.windows.net'
driver_df_timestamp.write.mode('overwrite').parquet(f"{processed_folder_path}/drivers.json")

# COMMAND ----------

driver_df_timestamp.write.mode('overwrite').format("parquet").saveAsTable("f1_processed.drivers")