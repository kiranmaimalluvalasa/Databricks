# Databricks notebook source
# MAGIC %md
# MAGIC ### Ingest circuits.csv file

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Step 1 - Read the CSV file using the spark dataframe reader

# COMMAND ----------

spark.conf.set("fs.azure.account.key.formula1dlprj25.dfs.core.windows.net","f7uc/rpPf7iG+ZDMf5pw6T4JVUgZai/CrnD1W9idUM3xnjJex0h05EWgFPDDOzEySwM+L6JRTRs7+AStyid4xg==")

# COMMAND ----------

display(dbutils.fs.ls("abfss://raw1@formula1dlprj25.dfs.core.windows.net"))

# COMMAND ----------

display(spark.read.csv("abfss://raw1@formula1dlprj25.dfs.core.windows.net/circuits.csv"))

# COMMAND ----------

circuit_df =(spark.read.csv("abfss://raw1@formula1dlprj25.dfs.core.windows.net/circuits.csv"))

# COMMAND ----------

type(circuit_df)

# COMMAND ----------

circuit_df.show()

# COMMAND ----------

circuit_df.printSchema()

# COMMAND ----------

circuit_df.describe().show()

# COMMAND ----------

circuit_df=spark.read.option("inferSchema",True).csv("abfss://raw1@formula1dlprj25.dfs.core.windows.net/circuits.csv")

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DoubleType

# COMMAND ----------

circuits_schema = StructType(fields=[StructField("circuitId", IntegerType(), True),
                                     StructField("circuitRef", StringType(), True),
                                     StructField("name", StringType(), True),
                                     StructField("location", StringType(), True),
                                     StructField("country", StringType(), True),
                                     StructField("lat", DoubleType(), True),
                                     StructField("lng", DoubleType(), True),
                                     StructField("alt", IntegerType(), True),
                                     StructField("url", StringType(), True) 
                                     ])

# COMMAND ----------

circuit_df = spark.read \
.option("header", True) \
.schema(circuits_schema) \
.csv("abfss://raw1@formula1dlprj25.dfs.core.windows.net/circuits.csv")

# COMMAND ----------

# MAGIC %md
# MAGIC ####2.Select Required col

# COMMAND ----------

circuit_selected_df=circuit_df.select("circuitId","circuitRef","name","location","country","lat","lng","alt","url")

# COMMAND ----------

circuit_selected_df=circuit_df.select(circuit_df.circuitId,circuit_df.circuitRef,circuit_df.name,circuit_df.location,circuit_df.country,circuit_df.lat,circuit_df.lng,circuit_df.alt,circuit_df.url)

# COMMAND ----------

circuit_selected_df=circuit_df.select(circuit_df["circuitId"],circuit_df["circuitRef"],
                                      circuit_df["name"],circuit_df["location"],circuit_df["country"])

# COMMAND ----------

from pyspark.sql.functions import col

# COMMAND ----------

circuit_selected_df=circuit_df.select(col("circuitId"),col("circuitRef"),col("name"),col("location"),col("country"),col("lat"),col("lng"),col("alt"),col("url"))

# COMMAND ----------

display(circuit_selected_df)

# COMMAND ----------

circuits_renamed_df = circuit_selected_df.withColumnRenamed("circuitId", "circuit_id") \
.withColumnRenamed("circuitRef", "circuit_ref") \
.withColumnRenamed("lat", "latitude") \
.withColumnRenamed("lng", "longitude") \
.withColumnRenamed("alt", "altitude") 

# COMMAND ----------

display(circuits_renamed_df)


# COMMAND ----------

# MAGIC %md 
# MAGIC 4.Adding an "ingestion date" to a DataFrame

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

circuits_final_df = circuits_renamed_df.withColumn("ingestion_date", current_timestamp()) 

# COMMAND ----------

display(circuits_final_df)

# COMMAND ----------

circuits_final_df.write.mode('overwrite').parquet("abfss://processed@formula1dlprj25.dfs.core.windows.net/circuit.csv")

# COMMAND ----------

display(spark.read.parquet("abfss://processed@formula1dlprj25.dfs.core.windows.net/circuit.csv"))

# COMMAND ----------

circuits_final_df.write.mode('overwrite').format("parquet").saveAsTable("f1_processed.circuit")