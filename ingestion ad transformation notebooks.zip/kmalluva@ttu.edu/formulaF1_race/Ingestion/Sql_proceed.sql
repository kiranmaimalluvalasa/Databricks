-- Databricks notebook source
SHOW DATABASES;

-- COMMAND ----------

SELECT current_database()

-- COMMAND ----------

USE f1_processed

-- COMMAND ----------

SHOW TABLES;

-- COMMAND ----------

SELECT * FROM f1_processed.drivers;


-- COMMAND ----------

SELECT nationality,COUNT(*)
FROM f1_processed.drivers
GROUP BY nationality


-- COMMAND ----------

SELECT nationality,COUNT(*)
FROM f1_processed.drivers
GROUP BY nationality
ORDER BY nationality

-- COMMAND ----------

SELECT nationality,COUNT(*)
FROM f1_processed.drivers
GROUP BY nationality
HAVING count(1) >100
ORDER BY nationality

-- COMMAND ----------

SELECT nationality,name,dob,RANK() OVER (PARTITION BY nationality ORDER BY dob DESC ) AS age_rank
FROM f1_processed.drivers

-- COMMAND ----------

