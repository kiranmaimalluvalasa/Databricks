# Databricks notebook source
dbutils.fs.ls('/')

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /databricks-datasets
# MAGIC