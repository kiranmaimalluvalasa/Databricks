# Databricks notebook source
# MAGIC %md
# MAGIC Access dataframes using SQL
# MAGIC Objectives
# MAGIC Create temporary views on dataframes
# MAGIC Access the view from SQL cell
# MAGIC Access the view from Python cell

# COMMAND ----------

spark.conf.set("fs.azure.account.key.formula1dlprj25.dfs.core.windows.net","f7uc/rpPf7iG+ZDMf5pw6T4JVUgZai/CrnD1W9idUM3xnjJex0h05EWgFPDDOzEySwM+L6JRTRs7+AStyid4xg==")

# COMMAND ----------

presentation_folder_path='abfss://presentation@formula1dlprj25.dfs.core.windows.net'
race_results=spark.read.parquet(f"{presentation_folder_path}/race_results")

# COMMAND ----------

race_results.createOrReplaceTempView("v_race_results")

# COMMAND ----------

