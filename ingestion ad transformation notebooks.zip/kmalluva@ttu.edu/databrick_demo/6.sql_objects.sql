-- Databricks notebook source
-- MAGIC %python
-- MAGIC spark.conf.set("fs.azure.account.key.formula1dlprj25.dfs.core.windows.net","f7uc/rpPf7iG+ZDMf5pw6T4JVUgZai/CrnD1W9idUM3xnjJex0h05EWgFPDDOzEySwM+L6JRTRs7+AStyid4xg==")

-- COMMAND ----------

CREATE DATABASE demo;



-- COMMAND ----------

SHOW DATABASES

-- COMMAND ----------

DESCRIBE DATABASE EXTENDED demo;

-- COMMAND ----------

SELECT current_database()

-- COMMAND ----------

-- MAGIC %md Settiing up the database

-- COMMAND ----------

USE demo

-- COMMAND ----------

SELECT current_database()

-- COMMAND ----------

-- MAGIC %python
-- MAGIC spark.conf.set("fs.azure.account.key.formula1dlprj25.dfs.core.windows.net","f7uc/rpPf7iG+ZDMf5pw6T4JVUgZai/CrnD1W9idUM3xnjJex0h05EWgFPDDOzEySwM+L6JRTRs7+AStyid4xg==")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC presentation_folder_path='abfss://presentation@formula1dlprj25.dfs.core.windows.net'
-- MAGIC results_df= spark.read.parquet(f"{presentation_folder_path}/race_results")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC results_df.write.format("parquet").saveAsTable("demo.race_results")

-- COMMAND ----------

USE demo;
SHOW TABLES;

-- COMMAND ----------

DESC race_results;

-- COMMAND ----------

DESC EXTENDED race_results;

-- COMMAND ----------

SELECT * FROM race_results;

-- COMMAND ----------

SELECT * FROM race_results
WHERE racer_year = 2020;

-- COMMAND ----------

CREATE TABLE racer_sql
AS
SELECT * FROM demo.race_results
WHERE racer_year = 2020;

-- COMMAND ----------

SHOW TABLES IN demo;

-- COMMAND ----------

DESC EXTENDED demo.racer_sql ;

-- COMMAND ----------

DROP TABLE demo.racer_sql 

-- COMMAND ----------

-- MAGIC %python
-- MAGIC spark.conf.set("fs.azure.account.key.formula1dlprj25.dfs.core.windows.net","f7uc/rpPf7iG+ZDMf5pw6T4JVUgZai/CrnD1W9idUM3xnjJex0h05EWgFPDDOzEySwM+L6JRTRs7+AStyid4xg==")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC presentation_folder_path='abfss://presentation@formula1dlprj25.dfs.core.windows.net'
-- MAGIC results_df.write.format("parquet").option("path",f"{presentation_folder_path}/race_results_ext_py").saveAsTable("demo.race_results_ext_py")
-- MAGIC

-- COMMAND ----------

-- MAGIC %python
-- MAGIC results_df.printSchema()

-- COMMAND ----------

DESC EXTENDED  race_results_ext_py

-- COMMAND ----------

CREATE TABLE demo.race_results_ext_sql
(race_year INT,
race_name STRING,
race_date TIMESTAMP,
circuit_location STRING,
driver_name STRING,
driver_number INT,
driver_nationality STRING,
team STRING,
grid INT,
fastest_lap INT,
race_time STRING,
points FLOAT,
position INT,
created_date TIMESTAMP
)
USING parquet



-- COMMAND ----------

SHOW TABLES IN demo;

-- COMMAND ----------

