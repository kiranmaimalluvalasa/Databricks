# Databricks notebook source
# MAGIC %md
# MAGIC #introduction to notebook
# MAGIC ## learnt magic commands
# MAGIC  - %sql
# MAGIC  -%scala
# MAGIC  -%sh
# MAGIC  -%fs

# COMMAND ----------

message='welcome to databrick experiement'

# COMMAND ----------

print(message)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT("HELLO KIRAN")

# COMMAND ----------

# MAGIC %fs
# MAGIC ls

# COMMAND ----------

# MAGIC %sh
# MAGIC ps
# MAGIC