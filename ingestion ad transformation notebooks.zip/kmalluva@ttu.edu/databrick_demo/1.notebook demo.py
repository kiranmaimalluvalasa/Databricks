# Databricks notebook source
message='welcome to databrick experiement'

# COMMAND ----------

print(message)