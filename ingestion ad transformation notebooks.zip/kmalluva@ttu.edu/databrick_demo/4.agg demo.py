# Databricks notebook source
spark.conf.set("fs.azure.account.key.formula1dlprj25.dfs.core.windows.net","f7uc/rpPf7iG+ZDMf5pw6T4JVUgZai/CrnD1W9idUM3xnjJex0h05EWgFPDDOzEySwM+L6JRTRs7+AStyid4xg==")

# COMMAND ----------

presentation_folder_path='abfss://presentation@formula1dlprj25.dfs.core.windows.net'
race_result_df=spark.read.parquet(f"{presentation_folder_path}/race_results")

# COMMAND ----------

display(race_result_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Filter

# COMMAND ----------

demo_df=race_result_df.filter("racer_year == 2020")

# COMMAND ----------

display(demo_df)

# COMMAND ----------

from pyspark.sql.functions import count, countDistinct, sum

# COMMAND ----------

demo_df.select(count("*")).show()

# COMMAND ----------

demo_df.select(count("name")).show()

# COMMAND ----------

demo_df.select(countDistinct("name")).show()

# COMMAND ----------

demo_df.select(count("race_time")).show()

# COMMAND ----------

demo_df.groupBy("name").agg(sum("points").alias("total_points")).show()


# COMMAND ----------

demo_df.filter("driver_name = 'Lewis Hamilton'").select(sum("points")).show()